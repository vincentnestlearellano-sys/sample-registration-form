// TURN ON THE LIGHT

function toggleLight() {

    document.body.classList.add("light-on");

    document.getElementById("register").classList.add("show");

    document.getElementById("instruction").textContent =
        "Welcome! You can now create your account.";

    document.getElementById("switchBtn").textContent =
        "LIGHT IS ON";

}


// TURN OFF THE LIGHT

function turnOffLight() {

    document.body.classList.remove("light-on");

    document.getElementById("register").classList.remove("show");

    document.getElementById("instruction").textContent =
        "It's dark in here! Turn on the light to continue.";

    document.getElementById("switchBtn").innerHTML =
        '<span id="switchIcon">⏻</span> TURN ON THE LIGHT';

}


// SHOW OR HIDE PASSWORD

document.getElementById("showPassword").addEventListener("change", function() {

    const password = document.getElementById("password");

    password.type = this.checked ? "text" : "password";

});


// REGISTRATION FORM SUBMISSION

document.getElementById("registrationForm").addEventListener("submit", function(event) {

    event.preventDefault();

    const message = document.getElementById("message");

    message.textContent =
        "Congratulations! Your registration form is complete!";

    message.style.color = "#23834c";

});
